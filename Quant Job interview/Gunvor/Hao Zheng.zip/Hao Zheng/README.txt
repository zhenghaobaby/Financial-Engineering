For exercise 3, 
I gave up that, first I don't know how to import python UDFS in the excel even I see the website discription
it also cost me lots of time to search how to import that, but still, failed.
So I can't run even the most simple case, double_sum(a,b)
Because I rarely use excel to code and also I am not familiared with VBA. so I think for Q3, I still have many things to learn
Under time limition, I can't make my software work and finish that.


